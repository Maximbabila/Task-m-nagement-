import Task from "../models/taskModel.js"

export const createTask = async (req, res) => {
    try {
        const newTask = await Task.create(req.body);
        res.status(201).json(newTask);
    } catch (err) {
        res.status(400).json({ message: err.message });
        console.log(err)
    }
};

export const getTasks = async (req, res) => {
    const tasks = await Task.find();
    res.json(tasks);
};

export const getTask = async (req, res) => {
    const task = await Task.findById(req.params.id);
    res.json(task);
};

export const updateTask = async (req, res) =>{
    const updateTask = await Task.findByIdAndUpdate(
        req.params.id,
        req.body,
        {new:true}
    );
    res.json(updateTask);
}

export const deleteTask = async (req,res) =>{
    await Task.findByIdAndDelete(req.params.id);
    res.json({message: "Task Deleted"})
}