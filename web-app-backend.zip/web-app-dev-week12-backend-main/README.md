# Task Management Backend API

A Node.js REST API for managing tasks built with Express, MongoDB, and Mongoose. This API follows the MVC (Model-View-Controller) architecture pattern.

## Overview

This backend provides a complete CRUD (Create, Read, Update, Delete) interface for task management. The API is structured in layers where each file has a specific responsibility.

## How It Works

### Data Flow

When a client makes a request, it flows through the system in this order:
1. Client sends HTTP request
2. **Server.js** receives and initializes the request
3. **Routes** match the request to the correct handler
4. **Controller** processes the business logic
5. **Model** validates and interacts with MongoDB
6. Response is sent back to the client

### File Explanations

#### **server.js** - Application Entry Point
This is the main file that starts everything. It:
- Loads environment variables from the `.env` file (like database connection details)
- Creates an Express application instance
- Sets up middleware to handle JSON data in requests
- Connects to MongoDB using Mongoose
- Registers all the routes at the `/api/tasks` path
- Starts the server on port 5000

The server acts as the traffic controller - it receives all incoming requests and directs them to the appropriate routes.

#### **Models/taskModel.js** - Database Schema
This file defines what a task looks like in the database. It specifies:
- **title** - A required string field where task descriptions are stored
- **completed** - A boolean that tracks if the task is done (defaults to false)
- **createdAt** - A date field that automatically records when the task was created

The model is like a blueprint - it ensures that every task in the database has these exact fields with the correct data types. It also handles validation (e.g., a title must be provided).

#### **Routes/taskRoutes.js** - API Endpoints
This file defines which URLs are available and maps them to controller functions. It specifies:
- `POST /api/tasks` - Creates a new task
- `GET /api/tasks` - Gets all tasks
- `GET /api/tasks/:id` - Gets a specific task by ID
- `PUT /api/tasks/:id` - Updates an existing task
- `DELETE /api/tasks/:id` - Deletes a task

Routes are like signs that direct traffic to the correct handler. When a request comes in, the routes figure out which controller function should handle it.

#### **Controllers/taskController.js** - Business Logic
This file contains the actual logic for each operation. It has five functions:
- **createTask** - Takes data from the request, validates it using the model, saves it to the database, and returns the created task with a 201 status
- **getTasks** - Queries the database to retrieve all tasks and returns them
- **getTask** - Finds a single task by its ID and returns it
- **updateTask** - Finds a task by ID, updates it with new data, and returns the updated version
- **deleteTask** - Finds and removes a task from the database, returns a confirmation message

The controllers handle errors gracefully - if something goes wrong (like missing required fields), they return an appropriate error response instead of crashing.

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/api/tasks` | Create a new task |
| GET | `/api/tasks` | Get all tasks |
| GET | `/api/tasks/:id` | Get a specific task |
| PUT | `/api/tasks/:id` | Update a task |
| DELETE | `/api/tasks/:id` | Delete a task |

## Setup

1. Create a `.env` file in the backend folder with:
   ```
   MONGO_URI= mongodb+srv://nkemazebless58_db_user:<password>@cluster0.gsnoeqx.mongodb.net/tasks?retryWrites=true&w=majority
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the server:
   ```bash
   npm start
   ```

The server will run on `http://localhost:5000`

## Testing

Use Postman or a similar tool to test the API:
- Set the request method (POST, GET, PUT, DELETE)
- Set the URL (e.g., `http://localhost:5000/api/tasks`)
- For POST/PUT requests, add JSON data in the body
- Click Send to make the request

## Project Structure

```
backend/
├── project/
│   ├── server.js              # Main application file
│   ├── controllers/
│   │   └── taskController.js  # Business logic
│   ├── models/
│   │   └── taskModel.js       # Database schema
│   └── Routes/
│       └── taskRoutes.js      # API routes
├── .env                        # Environment variables
└── package.json
```

## Summary

The system works like a restaurant: **Routes** are the host who directs customers to tables, **Controllers** are the chefs who prepare the meals, and **Models** are the recipes that ensure consistency. **Server.js** runs everything and manages the flow of requests and responses.
