import express from "express";
import dotenv from "dotenv";
import taskRoutes from "./Routes/taskRoutes.js";
import connectDB from "./config/db.js"
import cors from "cors";

dotenv.config();
connectDB();

const app = express()

app.use(cors({
  origin: [
    "http://localhost:5173",
    "https://web-app-frontend.vercel.app"
  ],
  credentials: true
}));

app.use(express.json());

app.use("/api/tasks", taskRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
}); 