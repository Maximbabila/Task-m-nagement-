import mongoose from "mongoose";

const taskSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, "Task title is requred"],
        trim: true,
    },
    completed: {
        type: Boolean,
        default: false,
    },
    createdAt : {
        type: Date,
        default: Date.now,
    }
});

export default mongoose.model("task", taskSchema)
